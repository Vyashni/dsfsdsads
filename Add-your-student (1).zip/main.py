from tkinter import *
from tkinter import messagebox
import sys
import sqlite3
from PIL import Image, ImageTk

def connection():
    try:
        conn=sqlite3.connect("student.db")
    except:
        print("cannot connect to the database")
    return conn    


def Add():
  class adde():
    def __init__(self,adds):
      self.titlea=Label(adds, text="Fill the details to add a student")
      self.titlea.place(x=100,y=100)
      self.namea=Label(adds, text="Name")
      self.namea.place(x=20,y=140)
      self.nama=Entry(adds)
      self.nama.place(x=160,y=140)
      self.n=self.nama.get()
      self.cs=Label(adds, text="Class and Section")
      self.cs.place(x=20,y=180)
      self.csa=Entry(adds)
      self.csa.place(x=160,y=180)
      self.c=self.csa.get()
      self.roll=Label(adds, text="Roll Number")
      self.roll.place(x=20,y=220)
      self.rolla=Entry(adds)
      self.rolla.place(x=160,y=220)
      self.r=self.rolla.get()
      self.addn=Label(adds, text="Admission number")
      self.addn.place(x=20,y=260)
      self.addna=Entry(adds)
      self.addna.place(x=160,y=260)
      self.a=self.addna.get()
      self.pn=Label(adds, text="Parent's name")
      self.pn.place(x=20,y=300)
      self.pna=Entry(adds)
      self.pna.place(x=160,y=300)
      self.p=self.pna.get()
      self.bg=Label(adds,text="Blood group")
      self.bg.place(x=20,y=340)
      self.bga=Entry(adds)
      self.bga.place(x=160,y=340)
      self.b=self.bga.get()
      self.hw=Label(adds, text="Height and Weight")
      self.hw.place(x=20,y=380)
      self.hwa=Entry(adds)
      self.hwa.place(x=160,y=380)
      self.h=self.hwa.get()
      self.sd=Label(adds, text="Sibling Details")
      self.sd.place(x=20,y=420)
      self.sda=Entry(adds)
      self.sda.place(x=160,y=420)
      self.s=self.sda.get()

      self.abutton=Button(adds,text="Add a student",command=self.adding)
      self.abutton.place(x=180,y=460)


    def adding(self):
      if self.n==" " and self.c==" " and self.r==" " and self.a==" " and self.p==" " and self.b==" " and self.h==" " and self.s==" ":  
        messagebox.showinfo("Error","Add all the fields")
      else: 
        answer=messagebox.askquestion("Are you sure?","Are you sure?")
        if answer=="yes": 
          conn=connection()
          cur=conn.cursor()
          cur.execute("CREATE TABLE IF NOT EXISTS STUDENT_DETAILS(NAME TEXT,CLASS TEXT,ROLL_NUMBER INTEGER,ADMISSION_NUMBER INTEGER,PARENT_NAME TEXT,BLOOD_GROUP TEXT,HEIGHTANDWEIGHT INTEGER, SIBLING_DETAILS TEXT)")
          cur.execute("insert into STUDENT_DETAILS values(?,?,?,?,?,?,?,?)",(self.n,self.c,self.r,self.a,self.p,self.b,self.h,self.s))
          conn.commit()
          conn.close()     
        messagebox.showinfo("Success","Successfully entered")

  adds=Toplevel()
  adds.geometry("600x600")
  adds.title("Add a student")
  app=adde(adds)
  adds.mainloop()


def Modify():
  class modee():
    def __init__(self,modifyy):
      self.d=Label(text="Student Name To Be Modified")
      self.titlee=Label(modifyy, text="Fill The Details To Modify A Student's Detail")
      self.titlee.place(x=120,y=100)
      self.sntbm=Label(modifyy, text="Student Name To Be Modified")
      self.sntbm.place(x=20,y=140)
      self.sntbmm=Entry(modifyy)
      self.sntbmm.place(x=300,y=140)
      self.s=self.sntbmm.get()
      self.wdywtm=Label(modifyy, text="What Do You Want To Modify")
      self.wdywtm.place(x=20,y=180)
      self.wdywtmm=Entry(modifyy)
      self.wdywtmm.place(x=300,y=180)
      self.w=self.wdywtmm.get()
      self.details=Label(modifyy, text="Details")
      self.details.place(x=20,y=220)
      self.detailss=Entry(modifyy)
      self.detailss.place(x=300,y=220)
      self.d=self.detailss.get()
      self.mbutton=Button(modifyy,text="Modify A Student",command=self.Modify)
      self.mbutton.place(x=180,y=300)
      self.mbutton=Button(modifyy,text="Back",command=self.goback)
      self.mbutton.place(x=350,y=300)

    def Modify(self):
      if self.s==" " and self.w==" " and self.d==" ":
        messagebox.showinfo("Error","Add all the fields")
      else: 
        answer=messagebox.askquestion("Are you sure?","Are you sure?")
        if answer=="yes": 
          conn=connection()
          cur=conn.cursor()
          cur.execute("UPDATE STUDENT_DETAILS SET Name=? where NAME=?",(self.d,self.s))
          conn.commit()
          conn.close()
        messagebox.showinfo("Success","Successfully modified")  


    def goback(self):
      screen=Tk()
      screen.geometry("500x500")
      screen.title("School Management System")
      screen.configure(background="white")
      name=Label(screen, text="Username")
      name.place(x=15,y=120)
      nname=Entry()
      nname.place(x=105,y=120)
      passw=Label(screen,text="Password")
      passw.place(x=15,y=160)
      ppassw=Entry(show="*")
      ppassw.place(x=105,y=160)
      submit= Button(text="Submit",command=usubmit)
      submit.place(x=130,y=220)
      cancel= Button(text="Cancel",command=ucancel)
      cancel.place(x=230,y=220)

  modees=Tk()
  modees.geometry("500x500")
  modees.title("Modify a Student")
  eee=modee(modees)
  modees.mainloop()

def Remove(): 
  class remove():
    def __init__(self,removee):
      self.d=Label(text="Student Name To Be Removed")
      self.tittle=Label(removee, text="Fill The Details To Remove A Student")
      self.tittle.place(x=100,y=100)
      self.sntbr=Label(removee, text="Student Name To Be Removed")
      self.sntbr.place(x=20,y=160)
      self.sntbrra=Entry(removee)
      self.sntbrra.place(x=250,y=160)
      self.r=self.sntbrra.get()
      self.rbutton=Button(removee,text="Remove A student",command=self.removing)
      self.rbutton.place(x=160,y=210)
      self.rbutton=Button(removee,text="Back",command=self.goback)
      self.rbutton.place(x=350,y=210)
    def removing(self):
      if self.r==" ":
        messagebox.showinfo("Error","Add the name to be deleted")
      else: 
        answer=messagebox.askquestion("Are you sure?","Are you sure?")
        if answer=="yes": 
          conn=connection()
          cur=conn.cursor()
          cur.execute("DELETE FROM STUDENT_DETAILS WHERE NAME=?",(self.r,))
          conn.commit()
          conn.close()
        messagebox.showinfo("Success","Successfully deleted")  
    def goback():
      screen=Tk()
      screen.geometry("500x500")
      screen.title("School Management System")
      screen.configure(background="white")
      name=Label(text="Username")
      name.place(x=15,y=120)
      nname=Entry()
      nname.place(x=105,y=120)
      passw=Label(text="Password")
      passw.place(x=15,y=160)
      ppassw=Entry(show="*")
      ppassw.place(x=105,y=160)
      submit= Button(text="Submit",command=usubmit)
      submit.place(x=130,y=220)
      cancel= Button(text="Cancel",command=ucancel)
      cancel.place(x=230,y=220)

  removees=Tk()
  removees.geometry("500x500")
  removees.title("Remove a Student")
  removee=remove(removees)
  removees.mainloop()

def Search(): 
  class searchee():
    def __init__(self,searchh):
      self.d=Label(text="Search A Student")
      self.titlle=Label(searchh, text="Search For A Student")
      self.titlle.place(x=100,y=100)
      self.sfas=Label(searchh, text="Student Name")
      self.sfas.place(x=20,y=140)
      self.sfasa=Entry(searchh)
      self.sfasa.place(x=160,y=140)
      self.f=self.sfasa.get()
      self.t1=Text(searchh,width=30,height=10)
      self.t1.place(x=30,y=160)
      self.sbutton=Button(searchh,text="Search",command=self.searching)
      self.sbutton.place(x=180,y=360)
      self.sbutton=Button(searchh,text="Back",command=self.goback)
      self.sbutton.place(x=350,y=360)

    def searching(self):
      if self.f==" ":
        messagebox.showinfo("Error","Add the name to be deleted")
      else: 
        answer=messagebox.askquestion("Are you sure?","Are you sure?")
        if answer=="yes": 
          conn=connection()
          cur=conn.cursor()
          cur.execute("select * from STUDENT_DETAILS WHERE Name=?",(self.f,))
          data=cur.fetchall()
          conn.close()
          for i in data:
            self.t1.insert(END,str(i)+"\n")
    def goback(self):
      screen=Tk()
      screen.geometry("500x500")
      screen.title("School Management System")
      screen.configure(background="white")
      name=Label(text="Username")
      name.place(x=15,y=120)
      nname=Entry()
      nname.place(x=105,y=120)
      passw=Label(text="Password")
      passw.place(x=15,y=160)
      ppassw=Entry(show="*")
      ppassw.place(x=105,y=160)
      submit= Button(text="Submit",command=usubmit)
      submit.place(x=130,y=220)
      cancel= Button(text="Cancel",command=ucancel)
      cancel.place(x=230,y=220)

        
  searchs=Tk()
  searchs.geometry("500x500")
  searchs.title("Remove a Student")
  sss=searchee(searchs)
  searchs.mainloop()


def usubmit():
  if nname.get()=="admin" and ppassw.get()=="123":
     messagebox.showinfo("Success","Login Success")
     Main=Tk()
     Main.geometry("500x500")
     Main.configure(background="white")
     head=Label(Main,text="Select what do you want to do")
     head.place(x=10,y=90)
     add=Button(Main, text="Add a student", command=Add)
     add.place(x=20,y=130)
     modify=Button(Main, text="Modify a student detail", command=Modify)
     modify.place(x=20,y=190)
     remove=Button(Main, text="Remove a student", command=Remove)
     remove.place(x=20,y=250)
     search=Button(Main, text="Search for a student", command=Search)
     search.place(x=20,y=310)
  else: 
    messagebox.showinfo("Check","Please check your login")
def ucancel():
  screen.destroy()
  sys.exit()
  

screen=Tk()
screen.geometry("500x500")
pic = Image.open("gg.jpg")
picture = ImageTk.PhotoImage(pic)
img = Label(image=picture)
img.image = picture
img.place(x=0, y=0)
screen.title("School Management System")
screen.configure(background="white")
name=Label(text="Username")
name.place(x=15,y=120)
nname=Entry()
nname.place(x=105,y=120)
passw=Label(text="Password")
passw.place(x=15,y=160)
ppassw=Entry(show="*")
ppassw.place(x=105,y=160)
submit= Button(text="Submit",command=usubmit)
submit.place(x=130,y=220)
cancel= Button(text="Cancel",command=ucancel)
cancel.place(x=230,y=220)
